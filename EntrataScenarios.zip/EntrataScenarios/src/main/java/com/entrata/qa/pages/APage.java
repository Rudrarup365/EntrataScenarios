package com.entrata.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.orangehrmlive.qa.base.TestBase;

public class APage extends TestBase{
	//PageFactory -OR
	@FindBy(xpath="//p[contains(text(),'Products')]")
	WebElement products;
	
	@FindBy(xpath="//p[contains(text(),'Solutions')]")
	WebElement solutions;
	
	@FindBy(xpath="//p[contains(text(),'Resources')]")
	WebElement resources;
	
	@FindBy(xpath="//p[contains(text(),'Summit')]")
	WebElement summit;
	
	@FindBy(xpath="//title[contains(@alt,'Property Management Software | Entrata')]")
	WebElement title;
	
	public APage() {
		PageFactory.initElements(driver, this);
	}
	public boolean validateAPage() {
		return(title.isEnabled());
	
	
}

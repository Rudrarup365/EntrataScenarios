package com.entrata.qa.teatcases;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import junit.framework.Assert;


/*
 * Test ID: 003
 * 1. Open Entrata url
 * 2. Check validity of navigation links from drop down
 */


public class TestScenario003Test {
	WebDriver driver;

    @BeforeMethod
    public void setUp() {
        driver = new ChromeDriver();
        driver.manage().deleteAllCookies();
        driver.manage().window().maximize();
        driver.get("https://www.entrata.com/a");
        Reporter.log("Url opened"); 
    }

    @Test (description = "Validate page navigations")
    public void validatePageNavigations() throws InterruptedException {
        // Pause for 2 seconds
        Thread.sleep(2000);
        // Validate page title
        String title = driver.getTitle();
        System.out.println(title);
        Assert.assertEquals(title, "Property Management Software | Entrata");
        System.out.println("Title showing successfully");
        Reporter.log("Title showing successfully<br>");

        // Decline cookies
        if (driver.findElement(By.xpath("/html/body/div[3]/div[2]/a[2]")).isDisplayed()) {
            driver.findElement(By.xpath("/html/body/div[3]/div[2]/a[2]")).click();
            System.out.println("Cookies declined successfully");
            Reporter.log("Cookies declined successfully<br>");
        }

        // Validate page navigation
        Actions action=new Actions(driver);
        action.moveToElement(driver.findElement(By.xpath("//div[text()='Products']"))).perform();
        Thread.sleep(2000);
        System.out.println("clicking "+ driver.findElement(By.xpath("/html/body/div[2]/div/div[1]/nav/div[1]/nav/div/div[2]/div[1]/a[2]")).getText());
        Reporter.log("clicking "+ driver.findElement(By.xpath("/html/body/div[2]/div/div[1]/nav/div[1]/nav/div/div[2]/div[1]/a[2]")).getText());
        driver.findElement(By.xpath("/html/body/div[2]/div/div[1]/nav/div[1]/nav/div/div[2]/div[1]/a[2]")).click();
        Assert.assertTrue(driver.findElement(By.xpath("//h1[text()='ResidentPay']")).isDisplayed());
        System.out.println("ResidentPay page is visible");
        Reporter.log("ResidentPay page is visible<br>");
        Thread.sleep(2000);
        driver.get("https://www.entrata.com/a");
        Thread.sleep(2000);
        //decline cookie
        if (driver.findElement(By.xpath("/html/body/div[3]/div[2]/a[2]")).isDisplayed()) {
            driver.findElement(By.xpath("/html/body/div[3]/div[2]/a[2]")).click();
        }
        action.moveToElement(driver.findElement(By.xpath("//div[text()='Products']"))).perform();
        Thread.sleep(2000);
        System.out.println("clicking "+ driver.findElement(By.xpath("//*[@id=\"w-dropdown-list-7\"]/div/div[2]/div[1]/a[3]")).getText());
        Reporter.log("clicking "+ driver.findElement(By.xpath("//*[@id=\"w-dropdown-list-7\"]/div/div[2]/div[1]/a[3]")).getText());
        driver.findElement(By.xpath("//*[@id=\"w-dropdown-list-7\"]/div/div[2]/div[1]/a[3]")).click();
        Assert.assertTrue(driver.findElement(By.xpath("//h1[text()='ResidentPortal']")).isDisplayed());
        System.out.println("ResidentPortal page is visible");
        Reporter.log("ResidentPortal page is visible<br>");
        
        Thread.sleep(2000);
        driver.get("https://www.entrata.com/a");
        Thread.sleep(2000);
        //decline cookie
        if (driver.findElement(By.xpath("/html/body/div[3]/div[2]/a[2]")).isDisplayed()) {
            driver.findElement(By.xpath("/html/body/div[3]/div[2]/a[2]")).click();
        }
        action.moveToElement(driver.findElement(By.xpath("//div[text()='Products']"))).perform();
        Thread.sleep(2000);
        System.out.println("clicking "+ driver.findElement(By.xpath("//*[@id=\"w-dropdown-list-7\"]/div/div[2]/div[1]/a[4]")).getText());
        Reporter.log("clicking "+ driver.findElement(By.xpath("//*[@id=\"w-dropdown-list-7\"]/div/div[2]/div[1]/a[4]")).getText());
        driver.findElement(By.xpath("//*[@id=\"w-dropdown-list-7\"]/div/div[2]/div[1]/a[4]")).click();
        Assert.assertTrue(driver.findElement(By.xpath("/html/body/section[1]/div[1]/div[1]/div[1]/div[1]/div/div[2]/h1")).isDisplayed());
        
        System.out.println("Business Intelligence page is visible");
        Reporter.log("Business Intelligence page is visible<br>");
        
 
    }

    @AfterMethod
    public void tearDown() {
        // Close browser after test execution
        driver.quit();
    }

}

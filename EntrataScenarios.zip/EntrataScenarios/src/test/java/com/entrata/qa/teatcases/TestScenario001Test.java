package com.entrata.qa.teatcases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import junit.framework.Assert;


/*
 * Test ID: 001
 * 1. Open Entrata url
 * 2. Check all fields for the Start seeing efficiency everywhere form
 */


public class TestScenario001Test {
	WebDriver driver;

    @BeforeMethod
    public void setUp() {
        driver = new ChromeDriver();
        driver.manage().deleteAllCookies();
        driver.manage().window().maximize();
        driver.get("https://www.entrata.com/a");
        Reporter.log("Url opened"); 
    }

    @Test (description = "Validate All form elements for blanks on main page")
    public void validateFormElements() throws InterruptedException {
        // Pause for 2 seconds
        Thread.sleep(2000);
        // Validate page title
        String title = driver.getTitle();
        System.out.println(title);
        Assert.assertEquals(title, "Property Management Software | Entrata");
        System.out.println("Title showing successfully");
        Reporter.log("Title showing successfully<br>");

        // Decline cookies
        if (driver.findElement(By.xpath("/html/body/div[3]/div[2]/a[2]")).isDisplayed()) {
            driver.findElement(By.xpath("/html/body/div[3]/div[2]/a[2]")).click();
            System.out.println("Cookies declined successfully");
            Reporter.log("Cookies declined successfully<br>");
        }

        // Validate form elements
        driver.findElement(By.xpath("//button[text()='Watch Demo']")).click();
        Assert.assertTrue(driver.findElement(By.xpath("//div[@id='ValidMsgFirstName']")).isDisplayed());
        System.out.println("Valid error message for blank FirstName");
        Reporter.log("Valid error message for blank FirstName<br>");

        driver.findElement(By.id("LastName")).click();
        Assert.assertTrue(driver.findElement(By.id("ValidMsgLastName")).isDisplayed());
        System.out.println("Valid error message for blank LastName");
        Reporter.log("Valid error message for blank LastName<br>");

        driver.findElement(By.id("Email")).click();
        Assert.assertTrue(driver.findElement(By.id("ValidMsgEmail")).isDisplayed());
        System.out.println("Valid error message for blank Email");
        Reporter.log("Valid error message for blank Email<br>");

        driver.findElement(By.id("Company")).click();
        Assert.assertTrue(driver.findElement(By.id("ValidMsgCompany")).isDisplayed());
        System.out.println("Valid error message for blank Company Name");
        Reporter.log("Valid error message for blank Company Name<br>");

        driver.findElement(By.id("Phone")).click();
        Assert.assertTrue(driver.findElement(By.xpath("//*[@id='ValidMsgPhone']/span")).isDisplayed());
        System.out.println("Valid error message for blank Phone Number");
        Reporter.log("Valid error message for blank Phone Number<br>");

        driver.findElement(By.id("Unit_Count__c")).click();
        Assert.assertTrue(driver.findElement(By.id("ValidMsgUnit_Count__c")).isDisplayed());
        System.out.println("Valid error message for blank Unit Count");
        Reporter.log("Valid error message for blank Unit Count<br>");

        driver.findElement(By.id("Title")).click();
        Assert.assertTrue(driver.findElement(By.id("ValidMsgTitle")).isDisplayed());
        System.out.println("Valid error message for blank Job Title");
        Reporter.log("Valid error message for blank Job Title<br>");

        driver.findElement(By.id("demoRequest")).click();
        Assert.assertTrue(driver.findElement(By.id("ValidMsgdemoRequest")).isDisplayed());
        System.out.println("Valid error message for blank I am");
        Reporter.log("Valid error message for blank I am<br>");
    }

    @AfterMethod
    public void tearDown() {
        // Close browser after test execution
        driver.quit();
    }

}

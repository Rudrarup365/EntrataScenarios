package com.entrata.qa.teatcases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import junit.framework.Assert;


/*
 * Test ID: 004
 * 1. Open Entrata url
 * 2. Check phone number field for wrong entries
 */
public class TestScenario004Test {
	WebDriver driver;

    @BeforeMethod
    public void setUp() {
        driver = new ChromeDriver();
        driver.manage().deleteAllCookies();
        driver.manage().window().maximize();
        driver.get("https://www.entrata.com/a");
        Reporter.log("Url opened"); 
    }

    @Test (description = "Validate Email and Phone number accepts valid entries on main page")
    public void validatePhone() throws InterruptedException {
        // Pause for 2 seconds
        Thread.sleep(2000);
        // Validate page title
        String title = driver.getTitle();
        System.out.println(title);
        Assert.assertEquals(title, "Property Management Software | Entrata");
        System.out.println("Title showing successfully");
        Reporter.log("Title showing successfully<br>");

        // Decline cookies
        if (driver.findElement(By.xpath("/html/body/div[3]/div[2]/a[2]")).isDisplayed()) {
            driver.findElement(By.xpath("/html/body/div[3]/div[2]/a[2]")).click();
            System.out.println("Cookies declined successfully");
            Reporter.log("Cookies declined successfully<br>");
        }

     // Validate form elements
        driver.findElement(By.xpath("//button[text()='Watch Demo']")).click();


        System.out.println("Trying asdf into phone field");
        Reporter.log("Trying asdf into phone field<br>");
        driver.findElement(By.id("Phone")).sendKeys("asdf");
        Assert.assertTrue(driver.findElement(By.xpath("//*[@id='ValidMsgPhone']/span")).isDisplayed());
        System.out.println("Valid error message for wrong Phone Number");
        Reporter.log("Valid error message for wrong Phone Number<br>");


    }

    @AfterMethod
    public void tearDown() {
        // Close browser after test execution
        driver.quit();
    }
}
